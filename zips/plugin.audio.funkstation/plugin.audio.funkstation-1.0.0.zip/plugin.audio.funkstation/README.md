# plugin.audio.funkstation
by Arber